package com.zybooks.finalproject.model;

import androidx.room.*;

@Dao
public interface AccountDao {
    @Query("SELECT * FROM Account WHERE email = :email")
    Account getAccount(String email);

    @Query("SELECT * FROM Account WHERE id = :id")
    Account getAccountById(long id);

    @Update
    void updateAccount(Account account);

    @Insert(onConflict = OnConflictStrategy.ABORT)
    long addAccount(Account account);

    @Delete
    void deleteAccount(Account account);
}

