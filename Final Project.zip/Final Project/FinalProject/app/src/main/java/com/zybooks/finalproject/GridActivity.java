package com.zybooks.finalproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;

import android.content.Intent;
import android.os.Bundle;

public class GridActivity extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid);

        NavHostFragment navHostFragment = (NavHostFragment) getSupportFragmentManager()
                .findFragmentById(R.id.nav_host_fragment);

        if (navHostFragment != null) {
            NavController navController = navHostFragment.getNavController();

            //  Create an accountId variable and set it to -1 by
            //  default. This value will be used to indicate an
            //  unset value
            long accountId = -1;

            //  Attempt to access the intent
            Intent intent = getIntent();

            //  If found with the accountId extra, extract it, but
            //  retain -1 as the error value if necessary
            if (intent != null && intent.hasExtra("accountId")) {
                accountId = intent.getLongExtra("accountId", -1);
            }

            //  Create a bundle to hold arguments
            Bundle args = new Bundle();
            args.putLong("accountId", accountId);

            //  Create the fragment to load and attach
            //  the arguments
            ItemListFragment fragment = new ItemListFragment();
            fragment.setArguments(args);

            //  Go to the fragment
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.nav_host_fragment, fragment).commit();
        }

    }
}