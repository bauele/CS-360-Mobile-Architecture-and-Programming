package com.zybooks.finalproject;

import static android.content.Context.NOTIFICATION_SERVICE;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.work.Data;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

public class TimerWorker extends Worker {

    public final static String KEY_ITEMS_REMAINING = "com.zybooks.projecttwo.ITEMS_LEFT";
    private final static String CHANNEL_ID_TIMER = "channel_timer";
    private final NotificationManager mNotificationManager;
    private final static int NOTIFICATION_ID = 0;

    public TimerWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
        mNotificationManager = (NotificationManager) context.getSystemService(NOTIFICATION_SERVICE);
    }

    @NonNull
    @Override
    public Result doWork() {

        // Get remaining milliseconds from MainActivity
        Data inputData = getInputData();
        long itemsRemaining = inputData.getLong(KEY_ITEMS_REMAINING, -1);

        // Can't continue without remaining time
        if (itemsRemaining == -1) {
            return Result.failure();
        }

        else if (itemsRemaining == 2) {
            //  Create a notification
            createTimerNotificationChannel();
            createTimerNotification("Almost out of an item!");
        }

        return Result.success();
    }

    private void createTimerNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = getApplicationContext().getString(R.string.channel_name);
            String description = getApplicationContext().getString(R.string.channel_description);
            int importance = NotificationManager.IMPORTANCE_LOW;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID_TIMER, name, importance);
            channel.setDescription(description);

            // Register channel with system
            mNotificationManager.createNotificationChannel(channel);
        }
    }

    private void createTimerNotification(String text) {

        // Create notification with various properties
        Notification notification = new NotificationCompat.Builder(
                getApplicationContext(), CHANNEL_ID_TIMER)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(getApplicationContext().getString(R.string.app_name))
                .setContentText(text)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .build();

        // Post notification
        mNotificationManager.notify(NOTIFICATION_ID, notification);
    }
}