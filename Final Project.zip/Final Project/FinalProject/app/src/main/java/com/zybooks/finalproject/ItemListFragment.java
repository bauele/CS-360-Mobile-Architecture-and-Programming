package com.zybooks.finalproject;




import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;


import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.fragment.app.Fragment;
import androidx.work.Data;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;
import androidx.work.WorkRequest;

import com.zybooks.finalproject.model.Account;
import com.zybooks.finalproject.model.AppRepository;
import com.zybooks.finalproject.model.Item;

import java.util.List;

public class ItemListFragment extends Fragment {

    private long accountId = -1;
    private String accountEmail = "";
    private View rootView;
    private float pixelDpRatio;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_item_list, container, false);

        //  Get a handle to the root view of the layout
        GridLayout layout = (GridLayout) rootView;

        //  Value indicating the math needed to "translate" pixels into device density-specific units
        pixelDpRatio = getContext().getResources().getDisplayMetrics().density;

        //  Attempt to access arguments that may have been sent
        Bundle args = getArguments();
        if (args != null && args.containsKey("accountId")) {
            accountId = args.getLong("accountId", -1);

            //  If there was an accountId passed, get the associated
            //  email address
            if (accountId != -1) {
                Account account = AppRepository.getInstance(getContext()).getAccountById(accountId);
                accountEmail = account.getEmail();
            }
            Log.d("myApp", "AccountId is " + accountId);
        }

        return rootView;
    }

    @Override
    public void onResume() {
        super.onResume();

        //  Get a handle to the root view of the layout
        GridLayout layout = (GridLayout) rootView;

        //  Remove any existing elements
        layout.removeAllViews();

        //  Load all of the items
        loadItems();
    }

    public void onAddButtonClick(View view) {
        Intent intent = new Intent(requireContext(), AddItemActivity.class);
        intent.putExtra("accountId", accountId);
        mAddItemLauncher.launch(intent);
    }

    public void onIncrementItemQuantityButton(View view) {
        //  Extract itemId from tag
        long itemId = (long) view.getTag();

        //  Get the item from the database
        Item item = AppRepository.getInstance(getContext()).getItem(itemId);

        //  Increment item quantity
        item.setQuantity(item.getQuantity() + 1);
        AppRepository.getInstance(getContext()).updateItem(item);

        //  Get a handle to the root view of the layout
        GridLayout layout = (GridLayout) rootView;

        //  Remove any existing elements
        layout.removeAllViews();

        //  Load all of the items
        loadItems();
    }

    public void onDecrementItemQuantityButton(View view) {
        //  Extract itemId from tag
        long itemId = (long) view.getTag();

        //  Get the item from the database
        Item item = AppRepository.getInstance(getContext()).getItem(itemId);

        //  If quantity is 1, delete the item
        if (item.getQuantity() == 1) {
            AppRepository.getInstance(getContext()).deleteItem(item);
        }

        else if (item.getQuantity() == 2) {

            //  Get account from database
            Account account = AppRepository.getInstance(getContext()).getAccountById(accountId);

            //  If the user has notifications enabled, send a
            //  notification request
            if (account.getNotificationsEnabled()) {
                WorkRequest timerWorkRequest = new OneTimeWorkRequest.Builder(TimerWorker.class)
                        .setInputData(new Data.Builder().
                                putLong(TimerWorker.KEY_ITEMS_REMAINING, item.getQuantity())
                                .build()
                        ).build();

                WorkManager.getInstance(getContext()).enqueue(timerWorkRequest);
            }

            //  Modify the quantity
            item.setQuantity(item.getQuantity() - 1);
            AppRepository.getInstance(getContext()).updateItem(item);
        }

        //  Otherwise, modify the quantity and update it in database
        else {
            item.setQuantity(item.getQuantity() - 1);
            AppRepository.getInstance(getContext()).updateItem(item);
        }

        //  Get a handle to the root view of the layout
        GridLayout layout = (GridLayout) rootView;

        //  Remove any existing elements
        layout.removeAllViews();

        //  Load all of the items
        loadItems();
    }

    public void onDeleteItemButton(View view) {
        //  Extract itemId from tag
        long itemId = (long) view.getTag();

        //  Get the item from the database
        Item item = AppRepository.getInstance(getContext()).getItem(itemId);

        //  Delete the item
        AppRepository.getInstance(getContext()).deleteItem(item);

        //  Get a handle to the root view of the layout
        GridLayout layout = (GridLayout) rootView;

        //  Remove any existing elements
        layout.removeAllViews();

        //  Load all of the items
        loadItems();
    }

    public void loadItems() {
        GridLayout layout = (GridLayout) rootView;

        //  Create an element for the page title
        TextView pageTitle = new TextView(getContext());
        pageTitle.setTextColor(Color.WHITE);
        pageTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 34);
        pageTitle.setTypeface(pageTitle.getTypeface(), Typeface.BOLD);

        //  If account email was set, use that in the pageTitle
        if (accountId != -1 && !accountEmail.isEmpty()) {
            pageTitle.setText(accountEmail + "'s Items");
        }

        //  Otherwise, use a fallback
        else {
            pageTitle.setText("Items");
        }

        //  Set layout parameters for the page title and add it to the view
        GridLayout.LayoutParams pageTitlelayoutParams =
                new GridLayout.LayoutParams(GridLayout.spec(0),
                        GridLayout.spec(0, GridLayout.FILL, 4));
        pageTitlelayoutParams.setMargins(0, 0, 0, 80);
        pageTitle.setLayoutParams(pageTitlelayoutParams);
        layout.addView(pageTitle);

        //  Create an element for the button to add items to inventory
        Button addItem = new Button(getContext());
        addItem.setText(R.string.add);
        addItem.setTextColor(Color.WHITE);
        addItem.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        addItem.setTypeface(addItem.getTypeface(), Typeface.BOLD);
        addItem.setBackgroundResource(R.drawable.gold_button);
        addItem.setOnClickListener(this::onAddButtonClick);

        //  Set layout parameters for the button and add it to the view
        GridLayout.LayoutParams addItemButtonLayoutParams =
                new GridLayout.LayoutParams(GridLayout.spec(0),
                        GridLayout.spec(4));
        addItemButtonLayoutParams.setMargins(0, 0, 0, 80);
        addItem.setLayoutParams(addItemButtonLayoutParams);
        layout.addView(addItem);

        //  Create an element for the heading for the item name column
        TextView headingItemName = new TextView(getContext());
        headingItemName.setText(R.string.item_name);
        headingItemName.setTextColor(Color.WHITE);
        headingItemName.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        headingItemName.setTypeface(headingItemName.getTypeface(), Typeface.BOLD);

        //  Set layout parameters for the item name heading and add it to the view
        GridLayout.LayoutParams headingItemNameLayoutParams =
                new GridLayout.LayoutParams(GridLayout.spec(1), GridLayout.spec(0));
        headingItemNameLayoutParams.setGravity(Gravity.FILL_HORIZONTAL);
        headingItemNameLayoutParams.setMargins(0, 0, 20, 50);
        headingItemName.setLayoutParams(headingItemNameLayoutParams);
        layout.addView(headingItemName);

        //  Create an element for the heading for the quantity column
        TextView headingQuantity = new TextView(getContext());
        headingQuantity.setText(R.string.quantity);
        headingQuantity.setTextColor(Color.WHITE);
        headingQuantity.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        headingQuantity.setTypeface(headingQuantity.getTypeface(), Typeface.BOLD);

        //  Set layout parameters for the quantity heading and add it to the view
        GridLayout.LayoutParams headingQuantityLayoutParams =
                new GridLayout.LayoutParams(GridLayout.spec(1), GridLayout.spec(1));
        headingQuantityLayoutParams.setMargins(0, 0, 20, 50);
        headingQuantity.setLayoutParams(headingQuantityLayoutParams);
        layout.addView(headingQuantity);

        //  Iterate through every item in the list, and build a row with its name, quantity,
        //  increment button, decrement button, and delete button. The row variable starts
        //  at 2, because row 0 was used for the page title and row 1 was used for the grid headings
        int row = 2;

        //  Get a list of all the items from the user's account
        List<Item> itemList = AppRepository.getInstance(requireContext()).getItemsById(accountId);
        if (!itemList.isEmpty()) {
            for (Item item : itemList) {
                //  Create elements for every component in the row
                TextView itemName = new TextView(getContext());
                TextView quantity = new TextView(getContext());
                Button decreaseQuantityButton = new Button(getContext());
                Button increaseQuantityButton = new Button(getContext());
                Button deleteItemButton = new Button(getContext());

                //  Set up the item name view
                itemName.setTextColor(Color.WHITE);
                itemName.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
                itemName.setTypeface(itemName.getTypeface(), Typeface.BOLD);

                //  Set layout parameters for item name view
                GridLayout.LayoutParams itemNameButtonLayoutParams =
                        new GridLayout.LayoutParams(GridLayout.spec(row), GridLayout.spec(0));
                itemNameButtonLayoutParams.setGravity(Gravity.FILL_HORIZONTAL);
                itemNameButtonLayoutParams.setMargins(0, 0, 20, 20);
                itemName.setLayoutParams(itemNameButtonLayoutParams);

                //  Set up the quantity view
                quantity.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                quantity.setTextColor(Color.WHITE);
                quantity.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
                quantity.setTypeface(itemName.getTypeface(), Typeface.BOLD);

                //  Set layout parameters for the quantity view
                GridLayout.LayoutParams quantityLayoutParams =
                        new GridLayout.LayoutParams(GridLayout.spec(row), GridLayout.spec(1));
                quantityLayoutParams.width = (int) (100 * pixelDpRatio);
                quantityLayoutParams.setMargins(0, 0, 0, 20);
                quantity.setLayoutParams(quantityLayoutParams);

                //  Set up the decrease quantity button view
                decreaseQuantityButton.setBackgroundResource(R.drawable.pink_button);
                decreaseQuantityButton.setTextColor(Color.WHITE);
                decreaseQuantityButton.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
                decreaseQuantityButton.setTag(item.getId());
                decreaseQuantityButton.setOnClickListener(this::onDecrementItemQuantityButton);

                //  Set layout parameters for the quantity button view
                GridLayout.LayoutParams decreaseQuantityButtonLayoutParams =
                        new GridLayout.LayoutParams(GridLayout.spec(row), GridLayout.spec(2));
                decreaseQuantityButtonLayoutParams.width = (int) (60 * pixelDpRatio);
                decreaseQuantityButton.setLayoutParams(decreaseQuantityButtonLayoutParams);
                decreaseQuantityButtonLayoutParams.setMargins(0, 0, 0, 20);

                //  Set up the increase quantity button view
                increaseQuantityButton.setBackgroundResource(R.drawable.pink_button);
                increaseQuantityButton.setTextColor(Color.WHITE);
                increaseQuantityButton.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
                increaseQuantityButton.setTag(item.getId());
                increaseQuantityButton.setOnClickListener(this::onIncrementItemQuantityButton);

                //  Set layout parameters for the increase quantity button view
                GridLayout.LayoutParams increaseQuantityButtonLayoutParams =
                        new GridLayout.LayoutParams(GridLayout.spec(row), GridLayout.spec(3));
                increaseQuantityButtonLayoutParams.width = (int) (60 * pixelDpRatio);
                increaseQuantityButtonLayoutParams.setMargins(5, 0, 0, 20);
                increaseQuantityButton.setLayoutParams(increaseQuantityButtonLayoutParams);

                //  Set up the delete item button view
                deleteItemButton.setBackgroundResource(R.drawable.blue_button);
                deleteItemButton.setTextColor(Color.WHITE);
                deleteItemButton.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
                deleteItemButton.setTag(item.getId());
                deleteItemButton.setOnClickListener(this::onDeleteItemButton);

                //  Set layout parameters for the delete item button view
                GridLayout.LayoutParams deleteItemButtonLayoutParams =
                        new GridLayout.LayoutParams(GridLayout.spec(row), GridLayout.spec(4));
                deleteItemButtonLayoutParams.setMargins(5, 0, 0, 20);
                deleteItemButton.setLayoutParams(deleteItemButtonLayoutParams);

                //  Set text values for all of the views
                itemName.setText(item.getName());
                String quantityString = String.valueOf(item.getQuantity());
                quantity.setText(quantityString);
                decreaseQuantityButton.setText(R.string.decrement_symbol);
                increaseQuantityButton.setText(R.string.increment_symbol);
                deleteItemButton.setText(R.string.delete);

                // Add all views to the layout
                layout.addView(itemName);
                layout.addView(quantity);
                layout.addView(decreaseQuantityButton);
                layout.addView(increaseQuantityButton);
                layout.addView(deleteItemButton);

                //  Increment the row
                row++;
            }
        }
    }

    private final ActivityResultLauncher<Intent> mAddItemLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent data = result.getData();
                        if (data != null) {
                            String itemName = data.getStringExtra("item");
                            int quantity = data.getIntExtra("quantity", -1);
                            boolean notificationsEnabled = data.getBooleanExtra("notificationsEnabled", false);

                            //  Create items from details
                            Item item = new Item(accountId, itemName, quantity);

                            //  Add item to database
                            AppRepository.getInstance(getContext()).addItem(item);
                        }
                    }
                }
            });
}