package com.zybooks.finalproject.model;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database (entities = {Account.class, Item.class}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {
    public abstract AccountDao accountDao();
    public abstract ItemDao itemDao();
}
