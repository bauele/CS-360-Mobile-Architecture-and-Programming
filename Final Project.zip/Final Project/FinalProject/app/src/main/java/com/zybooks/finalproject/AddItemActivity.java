package com.zybooks.finalproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.zybooks.finalproject.model.Account;
import com.zybooks.finalproject.model.AppRepository;

public class AddItemActivity extends AppCompatActivity {
    Intent mIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_item);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //  Store the intent for a later callback
        mIntent = getIntent();

        //  Load the account preferences to determines
        //  whether the notification box should be checked
        //  by default
        long accountId = mIntent.getLongExtra("accountId", -1);
        if (accountId != -1) {
            Account account = AppRepository.getInstance(getApplicationContext()).getAccountById(accountId);
            boolean notificationsEnabled = account.getNotificationsEnabled();

            //  If notifications are enabled, check the box
            if (notificationsEnabled) {
                CheckBox notificationsEnabledCheckBox = findViewById(R.id.checkbox_notifications);
                notificationsEnabledCheckBox.setChecked(true);
            }
        }
    }

    public void onNotificationsEnabledCheck(View view) {
        //  Determine if notification box is checked
        CheckBox notificationsEnabledCheckBox = findViewById(R.id.checkbox_notifications);
        boolean notificationsEnabled = notificationsEnabledCheckBox.isChecked();

        //  Update the account notifications settings
        long accountId = mIntent.getLongExtra("accountId", -1);
        Account account = AppRepository.getInstance(getApplicationContext()).getAccountById(accountId);
        account.setNotificationsEnabled(notificationsEnabled);
        AppRepository.getInstance(getApplicationContext()).updateAccount(account);
    }

    public void onAddItemButtonClick(View view) {
        //  Get the item name to be added
        EditText itemNameEditText = findViewById(R.id.item_name_field);
        String itemName = String.valueOf(itemNameEditText.getText());

        //  Get the item quantity to be added
        EditText quantityEditText = findViewById(R.id.quantity_field);
        String quantity = String.valueOf(quantityEditText.getText());

        //  Find the error prompt view
        TextView errorPrompt = findViewById(R.id.error_prompt);

        //  If either field is empty, display an error message
        if (itemName.isEmpty() || quantity.isEmpty()) {
            errorPrompt.setText("Please complete all fields");
            return;
        }

        //  Verify that the quantity field contains a number
        //  greater than zero
        int convertedQuantity;

        try {
            convertedQuantity = Integer.parseInt(quantity);

            if (convertedQuantity <= 0) {
                errorPrompt.setText("Quantity must greater than 0");
            }
        } catch (NumberFormatException e) {
            errorPrompt.setText("Quantity must be a number");
            return;
        }

        //  Get the intent from the calling activity and put extras
        mIntent.putExtra("item", itemName);
        mIntent.putExtra("quantity", convertedQuantity);

        //  Return to the caller
        setResult(RESULT_OK, mIntent);
        finish();
    }
}