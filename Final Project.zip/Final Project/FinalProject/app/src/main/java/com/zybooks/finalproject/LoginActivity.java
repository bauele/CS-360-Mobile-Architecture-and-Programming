package com.zybooks.finalproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.zybooks.finalproject.model.Account;
import com.zybooks.finalproject.model.AppRepository;

public class LoginActivity extends AppCompatActivity {

    private EditText mEmailAddressEditText;
    private EditText mPasswordEditText;
    private TextView mErrorPromptTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //  Identify the necessary views
        mEmailAddressEditText = findViewById(R.id.email_field);
        mPasswordEditText = findViewById(R.id.password_field);
        mErrorPromptTextView = findViewById(R.id.error_prompt);
    }

    public void onSignInButtonClick(View view) {
        //  Get provided email address
        String email = String.valueOf(mEmailAddressEditText.getText());

        //  Get provided password
        String password = String.valueOf(mPasswordEditText.getText());

        //  If the user did not enter anything in the email address
        //  field, display an appropriate error message
        if (email.isEmpty()) {
            mErrorPromptTextView.setText("Enter an email address");
            return;
        }

        //  If the user did not enter anything in the password
        //  field, display an appropriate error message
        if (password.isEmpty()) {
            mErrorPromptTextView.setText("Enter a password");
            return;
        }

        //  Otherwise, attempt to find an account matching their
        //  provided email address
        Account account = AppRepository.getInstance(getApplicationContext()).getAccount(email);

        //  If an account was not found, inform them that they
        //  must create an account first
        if (account == null) {
            mErrorPromptTextView.setText("Account not found. Click Create Acount instead.");
            return;
        }

        //  If the account was found, but the password is incorrect,
        //  show an error message
        else if (!account.getPassword().equals(password)) {
            mErrorPromptTextView.setText("Incorrect password. Please try again.");
        }

        //  Otherwise, direct them to their inventory page. Their
        //  accountId will be stored as an extra so that it can
        //  be used to display their items
        else {
            Intent intent = new Intent(LoginActivity.this, GridActivity.class);
            intent.putExtra("accountId", account.getId());
            startActivity(intent);
        }
    }

    public void onCreateAccountButtonClick(View view) {
        //  Get provided email address
        String email = String.valueOf(mEmailAddressEditText.getText());

        //  Get provided password
        String password = String.valueOf(mPasswordEditText.getText());

        //  If the user did not enter anything in the email address
        //  field, display an appropriate error message
        if (email.isEmpty()) {
            mErrorPromptTextView.setText("Enter an email address");
            return;
        }

        //  If the user did not enter anything in the password
        //  field, display an appropriate error message
        if (password.isEmpty()) {
            mErrorPromptTextView.setText("Enter a password");
            return;
        }

        //  Otherwise, attempt to find an account matching their
        //  provided email address
        Account account = AppRepository.getInstance(getApplicationContext()).getAccount(email);

        //  If an account was not found, create their account and
        //  direct them to their item page
        if (account == null) {
            Account newAccount = new Account(email, password);
            AppRepository.getInstance(getApplicationContext()).addAccount(newAccount);

            //  Retrieve the newly added account so that the id
            //  can be obtained
            Account addedAccount = AppRepository.getInstance(getApplicationContext()).getAccount(email);

            //  Ensure that the new account is valid
            if (addedAccount != null) {

                //  Direct them to their inventory page. Their
                //  accountId will be stored as an extra so that it can
                //  be used later
                Intent intent = new Intent(LoginActivity.this, GridActivity.class);
                intent.putExtra("accountId", addedAccount.getId());
                startActivity(intent);
            }
        }

        //  Otherwise, inform them that an account already exists
        //  and that they should sign in instead
        else {
            mErrorPromptTextView.setText("Account already exists. Click Sign In instead.");
        }
    }
}