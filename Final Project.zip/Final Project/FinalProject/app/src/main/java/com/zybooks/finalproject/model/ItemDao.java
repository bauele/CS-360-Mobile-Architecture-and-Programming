package com.zybooks.finalproject.model;

import androidx.room.*;

import java.util.List;

@Dao
public interface ItemDao {
    @Query("SELECT * FROM Item WHERE accountId = :accountId")
    List<Item> getItemsByAccountId (long accountId);

    @Query("SELECT * FROM Item WHERE id = :itemId")
    Item getItem(long itemId);

    @Insert(onConflict = OnConflictStrategy.ABORT)
    void addItem(Item item);

    @Update
    void updateItem(Item item);

    @Delete
    void deleteItem(Item item);
}

