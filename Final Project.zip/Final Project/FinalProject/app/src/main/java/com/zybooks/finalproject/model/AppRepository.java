package com.zybooks.finalproject.model;

import android.content.Context;
import androidx.room.Room;

import java.util.List;

public class AppRepository {

    private static AppRepository mAppRepo;
    private final AccountDao mAccountDao;
    private final ItemDao mItemDao;

    public static AppRepository getInstance(Context context) {
        if (mAppRepo == null) {
            mAppRepo = new AppRepository(context);
        }
        return mAppRepo;
    }

    private AppRepository(Context context) {
        AppDatabase database = Room.databaseBuilder(context, AppDatabase.class, "app.db")
                .allowMainThreadQueries()
                .build();

        mAccountDao = database.accountDao();
        mItemDao = database.itemDao();
    }

    public void addAccount(Account account) {
        mAccountDao.addAccount(account);
    }

    public Account getAccount(String email) {
        return mAccountDao.getAccount(email);
    }

    public Account getAccountById(long id) {return mAccountDao.getAccountById(id);}

    public void updateAccount(Account account) { mAccountDao.updateAccount(account); }

    public void deleteAccount(Account account) {
        mAccountDao.deleteAccount(account);
    }

    public List<Item> getItemsById(long id) { return mItemDao.getItemsByAccountId(id);}

    public void addItem(Item item) { mItemDao.addItem(item); }

    public Item getItem(long itemId) { return mItemDao.getItem(itemId); }

    public void updateItem(Item item) { mItemDao.updateItem(item);}

    public void deleteItem(Item item) { mItemDao.deleteItem(item);}
}