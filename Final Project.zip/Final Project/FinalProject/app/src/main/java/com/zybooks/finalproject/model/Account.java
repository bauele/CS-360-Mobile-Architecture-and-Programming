package com.zybooks.finalproject.model;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;


@Entity
public class Account {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private long mId;

    @NonNull
    @ColumnInfo(name = "email")
    private String mEmail;

    @NonNull
    @ColumnInfo(name = "password")
    private String mPassword;

    @ColumnInfo(name = "notificationsEnabled")
    private boolean mNotificationsEnabled;

    public Account(@NonNull String email, @NonNull String password) {
        mEmail = email;

        //  In a real world context, passwords should never be stored
        //  in plain text. There would be some sort of hashing algorithm
        //  performed first, but that is beyond the scope of this
        //  application
        mPassword = password;

        mNotificationsEnabled = false;
    }

    public void setId(long id) {
        mId = id;
    }

    public long getId() {
        return mId;
    }

    public void setEmail(String email) {
        mEmail = email;
    }

    public String getEmail() {
        return mEmail;
    }

    public void setPassword(String password) {
        mPassword = password;
    }

    public String getPassword() {
        return mPassword;
    }

    public void setNotificationsEnabled(boolean state) {mNotificationsEnabled = state;}

    public boolean getNotificationsEnabled() { return mNotificationsEnabled; }
}
